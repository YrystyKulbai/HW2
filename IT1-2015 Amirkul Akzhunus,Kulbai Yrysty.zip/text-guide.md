Simple, traffic-based pricing
Sign-up for our 30-day trial. No credit card required. 

Pageviews
$ /month

Monthly Billing
Yearly Billing 25% discount

Unlimited websites
100% data ownership
Email reports

Start my trial